/**
 * @author Libby Bakalar 
 * April 24, 2019 
 * This class will have the user choose electric or gas car
 */

import java.text.NumberFormat;
import java.util.Scanner;

public class UserInterface {
	
	static Scanner consoleScanner;
	static public double pumpCost;
	static int option = 0; 
	static double amt = 0; 

	public static void main(String[] args) {
		String again="Y";
		String validMake = "", validModel = "", validColor = "";
		String validFuelType = "", validBatType = "";
		int validYear = 0, validWeight = 0;
		double validTankSize = 0, validBatSize = 0;		
		ElectricCar emptyECar = new ElectricCar();
		GasCar emptyGCar = new GasCar();
		
		//calls init
		init();
		
		do {
			try {
				System.out.println("Enter 1 to enter a gas car");
				System.out.println("Enter 2 to enter an electric car");
				System.out.println("Enter anything else to exit");
				option = Integer.parseInt(consoleScanner.next());	
				
				if (option == 1 || option == 2) { 	
					// user enters make, model, color, year, and weight
					validMake = promptAndValidateMake();
					validModel = promptAndValidateModel();
					validColor = promptAndValidateColor();
					validYear = promptAndValidateYear();
					validWeight = promptAndValidateWeight();	
					
					if (option == 1) { // enter for a gas car
						validTankSize = promptAndValidateTankSize();
						validFuelType = promptAndValidateFuelType();
						pumpCost = promptForPumpCost();
						
						GasCar gCar = new GasCar(validMake, validModel, validColor, 
								validYear, validWeight, validTankSize, validFuelType);
						output(gCar, emptyECar);
					}
					if (option == 2) { // enter for an electric car
						validBatSize = promptAndValidateBatSize();
						validBatType = promptAndValidateBatType(); 
						pumpCost = promptForPumpCost();
						
						ElectricCar eCar = new ElectricCar(validMake, validModel, validColor, 
								validYear, validWeight, validBatSize, validBatType);
						output(emptyGCar, eCar);
					}
				}				
				System.out.print("\n" + "Enter again? (Y or N): " + "\n");
	        	again = consoleScanner.next();	
	        	
			} // bracket ends try
			
			catch (Exception e) {
				System.out.print("Program ending"); 
				System.exit(1);
				
			} // bracket ends catch
			
		} //bracket ends do 	
		
		while (again.toUpperCase().equals("Y"));{						
			System.out.print("Program ending"); 
			System.exit(1); 
		}					
	//bracket ends main 
	}
	
	public static void init() {
	   	consoleScanner = new Scanner(System.in);
	   	consoleScanner.useDelimiter(System.getProperty("line.separator"));	  	
	//bracket ends init	
	}
	
	public static String promptAndValidateMake() {
		String make = "";
		boolean ok = true;
		do {
    		ok = true;
    		try {
    			System.out.println("Enter make of car: ");
    			make = (consoleScanner.next());
    			if (make.isEmpty()) {
    				System.out.println("Error, please re-enter: ");
        			ok = false;
    			}
    		}
    		catch(Exception e) {
    			System.out.println("Error, please re-enter: ");
    			ok = false; 
    		}    		
    	}while(!ok);		
		return make;
	//bracket ends make	
	}
	
	public static String promptAndValidateModel() {
		String model = "";
		boolean ok = true;
		do {
    		ok = true;
    		try {
    			System.out.println("Enter model of car: ");
    			model = (consoleScanner.next());
    			if (model.isEmpty()) {
    				System.out.println("Error, please re-enter: ");
        			ok = false;
    			}
    		}
    		catch(Exception e) {
    			System.out.println("Error, please re-enter: ");
    			ok = false; 
    		}    		
    	}while(!ok);		
		return model;
	//bracket ends model	
	}
	
	public static String promptAndValidateColor() {
		String color = "";
		boolean ok = true;
		do {
    		ok = true;
    		try {
    			System.out.println("Enter color of car: ");
    			color = (consoleScanner.next());
    			if (color.isEmpty()) {
    				System.out.println("Error, please re-enter: ");
        			ok = false;
    			}
    		}
    		catch(Exception e) {
    			System.out.println("Error, please re-enter: ");
    			ok = false; 
    		}    		
    	}while(!ok);		
		return color;
	//bracket ends color	
	}
	
	public static int promptAndValidateYear() {
		int year = 0; 
    	boolean ok = true; 
    	
    	do {
    		ok = true;
    		try {
    			System.out.println("Enter year of car: ");
    			year = Integer.parseInt(consoleScanner.next());
    			
    		}
    		catch(Exception e) {
    			System.out.println("Error, please re-enter");
    			ok = false; 
    		}    		
    	}while(!ok);    	
		return year; 		
	//bracket ends valid year
	}
	
	public static int promptAndValidateWeight() {
		int weight = 0; 
    	boolean ok = true; 
    	
    	do {
    		ok = true;
    		try {
    			System.out.println("Enter weight of car: ");
    			weight = Integer.parseInt(consoleScanner.next());
    		}
    		catch(Exception e) {
    			System.out.println("Error, please re-enter");
    			ok = false; 
    		}    		
    	}while(!ok);    	
		return weight; 		
	//bracket ends valid weight	
	}
	
	public static double promptAndValidateTankSize() {
		double tankSize = 0;
		boolean ok = true;
		do {
    		ok = true;
    		try {
    			System.out.println("Enter tank size of car: ");
    			tankSize = Double.parseDouble(consoleScanner.next());
    		}
    		catch(Exception e) {
    			System.out.println("Error, please re-enter: ");
    			ok = false; 
    		}    		
    	}while(!ok);		
		return tankSize;
	//bracket ends valid tank size	
	}
	
	public static String promptAndValidateFuelType() {
		String fuelType = ""; 
    	boolean ok = true; 
    	
    	do {
    		ok = true;
    		try {
    			System.out.println("Enter fuel type of car: ");
    			fuelType = (consoleScanner.next());
    			if (fuelType.isEmpty()) {
    				System.out.println("Error, please re-enter: ");
        			ok = false;
    			}
    		}
    		catch(Exception e) {
    			System.out.println("Error, please re-enter");
    			ok = false; 
    		}    		
    	}while(!ok);    	
		return fuelType; 		
	//bracket ends valid fuel type
	}
	
	public static double promptAndValidateBatSize() {
		double batSize = 0;
		boolean ok = true;
		do {
    		ok = true;
    		try {
    			System.out.println("Enter battery size (in kilowatts) of car: ");
    			batSize = Double.parseDouble(consoleScanner.next());
    		}
    		catch(Exception e) {
    			System.out.println("Error, please re-enter: ");
    			ok = false; 
    		}    		
    	}while(!ok);		
		return batSize;
	//bracket ends valid battery size	
	}
	
	public static String promptAndValidateBatType() {
		String batType = ""; 
    	boolean ok = true; 
    	
    	do {
    		ok = true;
    		try {
    			System.out.println("Enter battery type of car: ");
    			batType = (consoleScanner.next());
    			if (batType.isEmpty()) {
    				System.out.println("Error, please re-enter: ");
        			ok = false;
    			}
    		}
    		catch(Exception e) {
    			System.out.println("Error, please re-enter");
    			ok = false; 
    		}    		
    	}while(!ok);    	
		return batType; 		
	//bracket ends valid battery type
	}
	
	public static double promptForPumpCost() {
		double pumpCost = 0;
		boolean ok = true;
		do {
    		ok = true;
    		try {
    			System.out.println("Enter pump cost: ");
    			pumpCost = Double.parseDouble(consoleScanner.next());
    		}
    		catch(Exception e) {
    			System.out.println("Error, please re-enter: ");
    			ok = false; 
    		}    		
    	}while(!ok);		
		return pumpCost;
	//bracket ends valid battery size
	}
	
	public static void output(GasCar gCar, ElectricCar eCar) {		
		NumberFormat nf = NumberFormat.getCurrencyInstance(java.util.Locale.US);
		String cost = "";
		
		if (option == 1) {
			System.out.println(gCar.toString());
			amt = gCar.CalcCostPerFill(pumpCost);
			cost = nf.format(amt);
			System.out.printf("Cost to fill tank: " + cost);
		}
		if (option == 2){
			System.out.println(eCar.toString());
			amt = eCar.CalcCostPerFill(pumpCost);
			cost = nf.format(amt);
			System.out.println("Cost to charge battery: " + cost);
		}
	//bracket ends output	
	}	
//bracket ends class	
}
