import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;

class ElectricCarTest extends ElectricCar{
	
	static ElectricCar testECar; 
	
	@BeforeAll 
	public static void onlyOnce() {
		testECar = new ElectricCar();
	}
	
	@Test
	void testSetBatSize() {
		testECar.setBatSize(0);
		assertEquals(testECar.getBatSize(), 70);
	}

	@Test
	void testSetBatteryType() {
		testECar.setBatteryType("");
		assertEquals(testECar.getBatteryType(), "Lithium ion");
	}

	@Test
	void testSetMake() {
		testECar.setMake("");
		assertEquals(testECar.getMake(), "Ford");
	}

	@Test
	void testSetModel() {
		testECar.setModel("");
		assertEquals(testECar.getModel(), "Taurus");
	}

	@Test
	void testSetColor() {
		testECar.setColor("");
		assertEquals(testECar.getColor(), "Black");
	}

	@Test
	void testSetYear() {
		testECar.setYear(0);
		assertEquals(testECar.getYear(), 2015);
	}

	@Test
	void testSetWeight() {
		testECar.setWeight(0);
		assertEquals(testECar.getWeight(), 3000);
	}
	
	@Test
	void testCalcCostPerFillPumpCost() {
		assertEquals(testECar.CalcCostPerFill(.4), 28);
	}

}
