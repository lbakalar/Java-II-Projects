import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;

class GasCarTest extends GasCar{
	
	static GasCar testGCar; 
	
	@BeforeAll 
	public static void onlyOnce() {
		testGCar = new GasCar();
	}

	@Test
	void testSetTankSize() {
		testGCar.setTankSize(0);
		assertEquals(testGCar.getTankSize(), 12);
	}

	@Test
	void testSetFuelType() {
		testGCar.setFuelType("");
		assertEquals(testGCar.getFuelType(), "Gasoline");
	}

	@Test
	void testSetMake() {
		testGCar.setMake("");
		assertEquals(testGCar.getMake(), "Ford");
	}

	@Test
	void testSetModel() {
		testGCar.setModel("");
		assertEquals(testGCar.getModel(), "Taurus");
	}

	@Test
	void testSetColor() {
		testGCar.setColor("");
		assertEquals(testGCar.getColor(), "Black");
	}

	@Test
	void testSetYear() {
		testGCar.setYear(0);
		assertEquals(testGCar.getYear(), 2015);
	}

	@Test
	void testSetWeight() {
		testGCar.setWeight(0);
		assertEquals(testGCar.getWeight(), 3000);
	}
	
	@Test
	void testCalcCostPerFillPumpCost() {
		assertEquals(testGCar.CalcCostPerFill(.5), 6);
	}

}
