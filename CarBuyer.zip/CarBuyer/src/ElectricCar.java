/** 
 * @author Libby Bakalar 
 * GasCar inherits make, model, color, year, and weight 
 * from Car class 
 *
 */
public class ElectricCar extends Car{
	
	protected double batSize; 
	protected String batType; 
	
	//getters 
	public double getBatSize(){
		return batSize;
	}
	
	public String getBatteryType(){
		return batType;
	}	
	
	//setters 
	public void setBatSize(double bs) {
		if (bs > 0) {
			batSize = bs;
		}
		else {
			batSize = 70;
		}	
	}
	
	public void setBatteryType(String bt) {
		if (bt.isEmpty()) {
			batType = "Lithium ion";
		}
		else {
			batType = bt;
		}	
	}
	
	//default constructor 
	public ElectricCar(){
		super();
		batSize = 70;
		batType = "Lithium ion"; 
	}
	
	/**
	 * 
	 * @param mke
	 * @param mod
	 * @param col
	 * @param yar
	 * @param wegt
	 * @param ko
	 * @param bty
	 */
	//overloaded constructor
	public ElectricCar(String mke, String mod, String col, int yar, int wegt, double ko, String bty){
		super(mke, mod, col, yar, wegt);
		setBatSize(ko);
		setBatteryType(bty);
	}		
	
	/**
	 * this calcCostPerFill will calculate cost to charge battery
	 * for electric cars (battery size * pumpCost)
	 */
	protected double CalcCostPerFill(double pumpCost) {
		return batSize * pumpCost;
	}
		
	//override toString 
	public String toString() {
		return super.toString() + "\n" + "Battery size in kilowatts: " + batSize + "  Battery Type: " + batType; 
	}
	
//bracket ends class 
}
