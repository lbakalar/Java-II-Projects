/**
 * 
 * @author Libby Bakalar 
 * Other classes (GasCar and ElectricCar) inherit 
 * make, model, color, year, and weight 
 * from this Car 
 */

public abstract class Car{
	protected String make, model, color;
	protected int year, weight;
	
	//getters 
	public String getMake(){
		return make;
	}
	public String getModel(){
		return model;
	}
	public String getColor(){
		return color;
	}	
	public int getYear(){
		return year;
	}	
	public int getWeight(){
		return weight;
	}
		
	//setters 
	public void setMake(String mkk) {
		if (mkk.isEmpty()) {
			make = "Ford";
		}
		else {
			make = mkk;
		}
	}
	public void setModel(String ml) {
		if (ml.isEmpty()) {
			model = "Taurus";
		}
		else {
			model = ml;
		}
	}
	public void setColor(String cr) {
		if (cr.isEmpty()) {
			color = "Black";
		}
		else {
			color = cr;
		}
	}
	
	public void setYear(int yearr) {
		if (yearr > 0) {
			year = yearr;
		}
		else {
			year = 2015;
		}	
	}
	
	public void setWeight(int weightt) {
		if (weightt > 0) {
			weight = weightt;
		}
		else {
			weight = 3000;
		}	
	}
		
	//default constructor 
	public Car(){
		make = "Ford";
		model = "Taurus";
		color= "Black";
		year = 2015;
		weight = 3000; 
	}
	
	
	/**
	 * 
	 * @param mk
	 * @param mo
	 * @param cl
	 * @param yr
	 * @param wt
	 */
	//overloaded constructor
	public Car(String mk, String mo, String cl, int yr, int wt){
		setMake(mk); 
		setModel(mo); 
		setColor(cl);
		setYear(yr);
		setWeight(wt); 
	}	
	
	//override toString 
	public String toString() {
		return "Make: " + make + "   Model: " + model + 
				"  Color: " + color + "  Year: " + year +
				"  Weight: " + weight;
	}
		
	/**
	 * 
	 * @param pumpCost
	 * @return
	 */
	//all child classes must implement move method
	protected abstract double CalcCostPerFill(double pumpCost);			
	
//bracket ends class	
}
