/** 
 * @author Libby Bakalar 
 * GasCar inherits make, model, color, year, and weight 
 * from Car class 
 *
 */
public class GasCar extends Car{	

	protected double tankSize;
	protected String fuelType;
	
	//getters 
	public double getTankSize(){
		return tankSize;
	}
	
	public String getFuelType(){
		return fuelType;
	}	
	
	//setters 
	public void setTankSize(double ts) {
		if (ts > 0) {
			tankSize = ts;
		}
		else {
			tankSize = 12;
		}	
	}
	
	public void setFuelType(String ft) {
		if (ft.isEmpty()) {
			fuelType = "Gasoline";
		}
		else {
			fuelType = ft;
		}	
	}
	
	//default constructor 
	public GasCar(){
		super();
		tankSize = 12;
		fuelType = "Gasoline"; 
	}
	
	/**
	 * 
	 * @param mke
	 * @param mod
	 * @param col
	 * @param yar
	 * @param wegt
	 * @param tz
	 * @param ftyp
	 */
	//overloaded constructor
	public GasCar(String mke, String mod, String col, int yar, int wegt, double tz, String ftyp){
		super(mke, mod, col, yar, wegt);
		setTankSize(tz);
		setFuelType(ftyp);
	}	
	
	/**
	 * this calcCostPerFill will calculate cost to fill tank
	 * for gas cars (tank size * pumpCost)
	 */	
	protected double CalcCostPerFill(double pumpCost) {
		return tankSize * pumpCost;
	}
	
	//override toString 
	public String toString() {
		return super.toString() + "\n" + "Tank Size: " + tankSize + "  Fuel Type: " + fuelType;
	}
	
//bracket ends class 	
}