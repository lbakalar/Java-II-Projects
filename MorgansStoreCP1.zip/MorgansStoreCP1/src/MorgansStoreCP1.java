/*
 * Libby Bakalar
 * This program is gain experience using two-dimensional arrays. 
 * This program includes reading data from a file and console input
 */

import java.io.File;
import java.io.FileNotFoundException;
import java.text.NumberFormat;
import java.util.Scanner;

public class MorgansStoreCP1 {	
	
	static NumberFormat nf;
	static double cRate; 
	static double cTotBonuses;
	static double cTotAvgBonus;
	static double[][] arrRates = new double [7][5];	
	static int cBonusCtr=0;
	
	static Scanner consoleScanner;
	static Scanner rateScanner; 

	public static void main(String[] args) {	
		
		double[][] arrAmounts = new double [7][5];
		int validWeeks =0; 
		int validReviews=0;		
		
		//call init
		init(arrAmounts, validWeeks, validReviews);
		
		input(arrAmounts, validWeeks, validReviews);
		
	//bracket ends main
	}
	
	public static void input(double[][] arrAmounts, int validWeeks, int validReviews) {
		String choice; 
		String again="Y";
		
		System.out.println("Enter 1 to enter data");
		System.out.println("Enter 2 to Display Summary");
		System.out.println("Enter anything else to exit");
		choice = consoleScanner.next();	
		
		if (choice.equals("1") || choice.equals("2")) {
			if (choice.equals("1")) {
				do {
					validWeeks = promptAndValidateWeeks();
					validReviews = promptAndValidateReviews();
					calcs(arrAmounts,validWeeks, validReviews);
					System.out.print("Enter again? (Y or N): " );
		        	again = consoleScanner.next();
					
				} while (again.toUpperCase().equals("Y"));{
					input(arrAmounts, validWeeks, validReviews);
				}
				
			}
			
			else {
				//if choice = 2	
				output(arrAmounts);
				input(arrAmounts, validWeeks, validReviews);
			}			 
		}
		else {
			System.out.print("Program ending"); 
			System.exit(1); 
		}
	//bracket ends input	
	}
	
	public static void init(double[][] arrAmounts, int r, int c) {
		
		
		//console Scanner 
    	consoleScanner = new Scanner(System.in);
    	consoleScanner.useDelimiter(System.getProperty("line.separator"));
    	
    	//rate file scanner
    	try {
    		rateScanner = new Scanner(new File("project1data.dat"));
    		rateScanner.useDelimiter(System.getProperty("line.separator"));
    		readRates();
    	} catch (FileNotFoundException e1){
    		System.out.println("File Error"); 
    		System.exit(1);
    	}				
    	
    	nf = NumberFormat.getCurrencyInstance(java.util.Locale.US);
    	
    	
    	for (r = 0; r < arrAmounts.length; r++) {
            for (c = 0; c < arrAmounts[r].length; c++) {
            	arrAmounts[r][c]=0; 
            }
        }
		
	//bracket ends init	
	}
	
	public static int promptAndValidateWeeks() {
		int weeks = 0; 
    	boolean ok = true; 
    	
    	do {
    		try {
    			System.out.println("Enter number of weeks worked: ");
    			weeks = Integer.parseInt(consoleScanner.next());
    			if (weeks < 0) {
    				System.out.println("Weeks but be zero or greater, re-enter");
    				ok = false; 
    			}
    			else {
    				ok = true; 
    			}
    		}
    		catch(Exception e) {
    			System.out.println("Weeks must be numeric, re-enter");
    			ok = false; 
    		}
    		
    	}while(!ok);
    	
		return weeks; 
		
	//bracket ends valid weeks	
	}
	
	public static int promptAndValidateReviews() {
		int reviews = 0; 
    	boolean ok = true; 
    	
    	do {
    		try {
    			System.out.println("Enter number of positive reviews: ");
    			reviews = Integer.parseInt(consoleScanner.next());
    			if (reviews < 0) {
    				System.out.println("Reviews but be zero or greater, re-enter");
    				ok = false; 
    			}
    			else {
    				ok = true; 
    			}
    		}
    		catch(Exception e) {
    			System.out.println("Reviews must be numeric, re-enter");
    			ok = false; 
    		}
    		
    	}while(!ok);
    	
    	return reviews; 
    	
    //bracket ends valid reviews	
	}
	
	public static void readRates() {
		String rateRecord = "";
		String rateRow[];
    	int row=0;
    	
		while(rateScanner.hasNextLine()) {
    		try {
    			//read a record
    			rateRecord = rateScanner.nextLine();
    			
    			//break the record into individual strings, splits up according to commas
    			rateRow = rateRecord.split(",");
    			
    			arrRates[row] = new double[rateRow.length];
    			 
    			for (int i=0; i< rateRow.length; i++) {
    				arrRates[row][i] = Double.parseDouble(rateRow[i]);
    			}
    			row++; 
    		}
    		catch (Exception e){
    			System.out.println("Error reading rate file, program ending"); 
    			System.exit(1);    		
    		}
    	}
	//bracket ends read rates	
	}
	
	public static void calcs(double[][] arrSpaces, int r, int c) {		
		
		cBonusCtr += 1; 
		
		for (int rr = 0; rr < 1; rr++) {
            for (int cc =0; cc < 1; cc++) {
            	cRate += arrRates[r][c];
            	arrSpaces[r][c] += cRate; 
            	cTotBonuses += cRate;
            	cRate =0; 
            }
        }
				
	//bracket to end calcs 	
	}
	
	public static void output(double[][] arrSpace) {
		String oTotBonuses; 
		String oTotAvgBonus; 
		int x=0; 
		
		cTotAvgBonus = cTotBonuses / cBonusCtr;
		
		System.out.format("\n\n%36s%7s", " ", "Reviews" );
		System.out.format("\n\n%5s%12s%1s%10s%1s%10s%1s%10s%1s%10s%7s\n", "Weeks"," ", "0", " ", "1", " ", "2", " ", "3", " ",  "4 more ");
		
		for (int r = 0; r < arrSpace.length; r++) {
			System.out.print("  " + x + "             ");
            for (int c = 0; c < arrSpace[r].length; c++) {
            	System.out.print(arrSpace[r][c] + "        " );
            }
            System.out.println("");
            x += 1;             
        }		
		
		oTotBonuses = nf.format(cTotBonuses);
		oTotAvgBonus = nf.format(cTotAvgBonus);
		
		System.out.format("\n\n%25s%10s%15s%23s%10s\n\n", "Total amount of bonuses: ", oTotBonuses, " ", "Overall average bonus: ", oTotAvgBonus);
		
		
	//bracket ends output	
	}
	
//bracket ends program
}
